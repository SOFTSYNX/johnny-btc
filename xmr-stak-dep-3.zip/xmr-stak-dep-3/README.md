# xmr-stak-dep
This repository only contains a binary build of xmr-stak dependencies. 

```
-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA256

SHA1 checksums
735224284f304fad07d4d2ea105f55c0a7248537  hwloc\lib\libhwloc.lib
40ea1aac4da94e64d8e252908b3a1dcf8930b729  libmicrohttpd\lib\libmicrohttpd.lib
7264c4c0792b84c05c5a9eed86ecb95be51f3ee7  openssl\lib\libeay32.lib
d96cadc47787ef0438f4ae947a5c79a48a8f6c7e  openssl\lib\ssleay32.lib
3f1634244ccd336f7df581e3c82e1c6ca38ce714  openssl\bin\libeay32.dll
538f3bd9dfcafc379e912562bcf343333f5375c7  openssl\bin\ssleay32.dll

date
Fri 21 Jul 23:52:31 BST 2017
-----BEGIN PGP SIGNATURE-----
Version: GnuPG v2

iQEcBAEBCAAGBQJZcoXDAAoJEPsk95p+1Bw026UIAJs6ss0MKziCxbGNTunfoviB
gojHhbHrcm5jdAP1PAdBPiyD1CXt2XDYMndgxzBAiscQ+i6ixetrxKPo210IywlG
ntt8KzCb8Vb+7j61o4iU1v8/jfMF5klD9EMAz3xNn90NHoO8U/0GTnrdaagy3TCp
w6C/gmRjZXiZ3UnDDdEv0Tbq5e4+L00NBUD3Zk8DqblrX0Eobkevnnz2CBJeAn/V
hN6dqE049JR0a+Yv+Q9ykIP3uxIII17fCVx9ks2dfDLvDDAM5juGLmZz8suVV+yA
uan0YXsIVXIT2g9j6HY5guEqQRs5CgPqLel8xRuhRM1a2qD8DSIyeuX+ee72UR0=
=ZIMk
-----END PGP SIGNATURE-----
```

# Source codes
* [hwloc](https://www.open-mpi.org/projects/hwloc/)
* [libmicrohttpd](https://www.gnu.org/software/libmicrohttpd/)
* [openssl](https://github.com/openssl/openssl)

